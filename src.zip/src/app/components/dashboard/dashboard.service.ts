import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { StyleManagerService } from 'src/app/style-manager.service';
import { IThemeOption, IThemeOptions } from '../../models/theme-option.model';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  private tableDataUrl = 'https://api.publicapis.org/entries'

  constructor(
    private _http: HttpClient,
    private _styleManager: StyleManagerService
  ) { }

  getThemeOptions(): Observable<IThemeOptions> {
    return this._http.get<IThemeOptions>("/assets/themes/theme-options.json");
  }

  setTheme(themeToSet: any) {
    console.log('set style')
    //this._styleManager.removeStyle(themeToSet);
    this._styleManager.setStyle(
      "theme",
      `node_modules/@angular/material/prebuilt-themes/${themeToSet}.css`
    );
  }


  getTableData = () => {
    return this._http.get(this.tableDataUrl);
  }
}
