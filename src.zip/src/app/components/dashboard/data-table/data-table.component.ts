import { AfterViewInit, ChangeDetectorRef, Component, OnChanges, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { map } from 'rxjs/operators';
import { DashboardService } from '../dashboard.service';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit {

  public ELEMENT_DATA: any = [];
  public filterSelectObj: any = [];
  public filterValues: any = {};
  public searchApplied: boolean = false;
  public tableIsLoaded: boolean = false;

  public searchText: string = '';
  // public displayedColumns: string[] = ['position', 'auth', 'category', 'https'];
  public displayedColumns: string[] = ['id', 'API', 'Category', 'HTTPS'];

  public dataSource = new MatTableDataSource();
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator = new MatPaginator(new MatPaginatorIntl(), ChangeDetectorRef.prototype);
  @ViewChild('empTbSort', { static: false }) empTbSort = new MatSort();

  constructor(
    private _dashboardService: DashboardService
  ) {
    // Object to create Filter for
    this.filterSelectObj = [
      {
        name: 'Category',
        columnProp: 'Category',
        options: []
      },
      {
        name: 'HTTPS',
        columnProp: 'HTTPS',
        options: []
      }
    ]
  }

  ngOnInit(): void {
    this.getTableData();
    // Overrride default filter behaviour of Material Datatable
    
  }

  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj: any, key: any) {
    const uniqChk: any = [];
    fullObj.filter((obj: any) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }

  getTableData = () => {
    this._dashboardService.getTableData()
      .pipe(
        map((res: any, index: number) => {
          console.log(res);
          const newRes = { ...res };
          newRes["entries"].map((entry: any, index: number) => entry.id = index);
          return newRes;
        })
      )

      .subscribe((res: any) => {
        console.log(res);
        
        this.dataSource.data = res["entries"];
        this.ELEMENT_DATA = res["entries"];
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.empTbSort;
        this.filterSelectObj.filter((o: any) => {
          console.log(o);
          o.options = this.getFilterObject(this.ELEMENT_DATA, o.columnProp);
        });
        this.dataSource.filterPredicate = this.createFilter();
        this.tableIsLoaded = true;
      });

  }

  applyFilter = (event: Event) => {
    this.searchApplied = true;
    const filterValue = (event.target as HTMLInputElement).value;
    console.log(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // Custom filter method fot Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      console.log(data);
      // console.log(this.dataSource);
      let searchTerms: any;
      if (filter.indexOf('{') > -1) {
        searchTerms = JSON.parse(filter);
        let isFilterSet = false;
        for (const col in searchTerms) {
          if (searchTerms[col].toString() !== '') {
            isFilterSet = true;
          } else {
            delete searchTerms[col];
          }
        }

        console.log(searchTerms);

        let nameSearch = () => {
          let found = false;
          if (isFilterSet) {
            for (const col in searchTerms) {
              searchTerms[col].trim().toLowerCase().split(' ').forEach((word: any) => {
                if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                  found = true
                }
              });
            }
            return found
          } else {
            return true;
          }
        }
        return nameSearch()
      } else {

        searchTerms = filter;
        let isFilterSet = false;
        // for (const col in searchTerms) {
          if (searchTerms.toString() !== '') {
            isFilterSet = true;
          }
        // }

        console.log(searchTerms);

        let nameSearch = () => {
          let found = false;
          if (isFilterSet) {
            console.log(data);
            for (const col in data) {
              data[col].trim().toLowerCase().split(' ').forEach((word: any) => {
                if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                  found = true
                }
              });
            }
            return found
          } else {
            return true;
          }
        }
        return nameSearch()
      }


    }
    return filterFunction
  }

  // Called on Filter change
  filterChange(filter: any, event: any) {
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.dataSource.filter = JSON.stringify(this.filterValues)
  }

  // Reset table filters
  resetFilters() {
    this.filterValues = {};
    this.filterSelectObj.forEach((value: any, key: string) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }

}
