import { ActionReducerMap } from '@ngrx/store';
import * as AuthActions from '../../app/components/auth/store/auth.actions';
import * as fromAuth from '../../app/components/auth/store/auth.reducer';

export interface AppState {
  auth: fromAuth.State;
}

export const appReducer: ActionReducerMap<AppState, AuthActions.AuthActions> = {
  auth: fromAuth.authReducer
};
