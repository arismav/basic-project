export interface IMenu {
    label: string,
    routerLink: string
}